document.addEventListener('DOMContentLoaded', function () {
    // Function to submit the quiz
    window.submitQuiz = function () {
        // Get the form element
        var quizForm = document.getElementById('quizForm');

        // Define correct answers
        var correctAnswers = {
            q1: 'a',
            q2: 'b',
            q3: 'a',
            q4: 'a',
            q5: 'b',
        };

        // Initialize variables
        var score = 0;
        var resultsHTML = '<h2>Quiz Results</h2>';

        // Loop through each question
        for (var i = 1; i <= 5; i++) {
            // Get selected answer and correct answer
            var selectedAnswer = quizForm.elements['q' + i].value;
            var correctAnswer = correctAnswers['q' + i];

            // Check if the answer is correct
            if (selectedAnswer === correctAnswer) {
                score++;
                resultsHTML += '<p class="correct">Question ' + i + ': Correct</p>';
            } else {
                resultsHTML += '<p class="incorrect">Question ' + i + ': Incorrect. Correct answer: ' + correctAnswer + '</p>';
            }
        }

        // Display results
        var quizResults = document.getElementById('quizResults');
        resultsHTML += '<p>Your total score: ' + score + ' out of 5.</p>';
        quizResults.innerHTML = resultsHTML;
    };
});
