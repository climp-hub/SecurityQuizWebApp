from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Define correct answers
correct_answers = {
    'q1': 'a',
    'q2': 'b',
    'q3': 'a',
    'q4': 'a',
    'q5': 'b',
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/quiz', methods=['POST'])
def process_quiz():
    try:
        # Get user's answers from the request
        user_answers = {key: request.form[key] for key in request.form if key.startswith('q')}
        
        # Calculate the score
        score = sum(1 for q, ans in user_answers.items() if ans == correct_answers[q])

        # Prepare the response
        response = {
            'score': score,
            'total_questions': len(correct_answers),
            'correct_answers': correct_answers,
        }

        return jsonify(response)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
